const SERVER_URL = "http://127.0.0.1:19198";
const PING_TIMEOUT_MS = 400;

async function isServerAlive() {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), PING_TIMEOUT_MS);
    const res = await fetch(`${SERVER_URL}/ping`, { signal: controller.signal });
    clearTimeout(timeout);
    return res.ok;
  } catch (e) {
    return false;
  }
}

async function isEnabled() {
  const data = await chrome.storage.local.get({ enabled: true });
  return data.enabled;
}

async function getCookieHeader(url) {
  try {
    const cookies = await chrome.cookies.getAll({ url });
    return cookies.map(c => `${c.name}=${c.value}`).join("; ");
  } catch (e) {
    return "";
  }
}

async function forwardDownload(downloadItem) {
  const cookies = await getCookieHeader(downloadItem.url);
  const payload = {
    url: downloadItem.url,
    filename: downloadItem.filename ? downloadItem.filename.split(/[\\/]/).pop() : "",
    referrer: downloadItem.referrer || "",
    cookies,
  };

  await fetch(`${SERVER_URL}/add`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}

chrome.downloads.onCreated.addListener(async (downloadItem) => {
  if (!(await isEnabled())) return;
  if (!downloadItem.url || downloadItem.url.startsWith("blob:") || downloadItem.url.startsWith("data:")) return;
  if (!(await isServerAlive())) return;

  try {
    await chrome.downloads.cancel(downloadItem.id);
    await chrome.downloads.erase({ id: downloadItem.id });
  } catch (e) {
    return;
  }

  await forwardDownload(downloadItem);
});
