const SERVER_URL = "http://127.0.0.1:19198";
const toggle = document.getElementById("enabledToggle");
const status = document.getElementById("status");

async function init() {
  const data = await chrome.storage.local.get({ enabled: true });
  toggle.checked = data.enabled;

  try {
    const res = await fetch(`${SERVER_URL}/ping`);
    status.textContent = res.ok ? "PyIDM is running" : "PyIDM not detected";
  } catch (e) {
    status.textContent = "PyIDM not detected";
  }
}

toggle.addEventListener("change", () => {
  chrome.storage.local.set({ enabled: toggle.checked });
});

init();
